﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork_Zoo
{
    class Animal
    {
        public Animal()
        {

        }
        public  virtual void feed()
        {
        Console.WriteLine("This is to feed Animal");
        }
    }

}
